export interface User {
  id: string;
  name: string;
  avatar: string;
}

export interface Photo {
  id: string;
  title: string;
  caption: string;
  imageUrl: string;
  category: string;
  likes: number;
  comments: number;
  user: User;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
}