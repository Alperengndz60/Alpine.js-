import React, { useState } from 'react';
import { ArrowLeft, Heart, MessageCircle, Share2, Bookmark } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import { photos } from '../data';

const PhotoDetail: React.FC = () => {
  const photo = photos[0]; // For demo, using the first photo
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(photo.likes);
  const [saved, setSaved] = useState(false);
  const [comment, setComment] = useState('');
  
  const handleLike = () => {
    if (liked) {
      setLikes(likes - 1);
    } else {
      setLikes(likes + 1);
    }
    setLiked(!liked);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <button className="flex items-center text-blue-600 mb-6 hover:underline">
          <ArrowLeft size={18} className="mr-2" />
          Geri Dön
        </button>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-2/3">
              <img 
                src={photo.imageUrl} 
                alt={photo.title} 
                className="w-full h-[500px] object-cover"
              />
            </div>
            
            <div className="md:w-1/3 p-6">
              <div className="flex items-center mb-4">
                <img 
                  src={photo.user.avatar} 
                  alt={photo.user.name} 
                  className="w-10 h-10 rounded-full mr-3"
                />
                <div>
                  <p className="font-medium">{photo.user.name}</p>
                  <p className="text-sm text-gray-500">2 saat önce</p>
                </div>
              </div>
              
              <h1 className="text-2xl font-bold mb-2">{photo.title}</h1>
              <p className="text-gray-700 mb-6 italic">"{photo.caption}"</p>
              
              <div className="flex items-center justify-between text-gray-500 mb-6">
                <div className="flex space-x-6">
                  <button 
                    className={`flex items-center ${liked ? 'text-red-500' : ''}`}
                    onClick={handleLike}
                  >
                    <Heart size={20} className={liked ? 'fill-current' : ''} />
                    <span className="ml-1">{likes}</span>
                  </button>
                  <button className="flex items-center">
                    <MessageCircle size={20} />
                    <span className="ml-1">{photo.comments}</span>
                  </button>
                  <button className="flex items-center">
                    <Share2 size={20} />
                  </button>
                </div>
                <button 
                  className={`${saved ? 'text-blue-500' : ''}`}
                  onClick={() => setSaved(!saved)}
                >
                  <Bookmark size={20} className={saved ? 'fill-current' : ''} />
                </button>
              </div>
              
              <div className="border-t border-gray-200 pt-6 mb-6">
                <h3 className="font-semibold text-lg mb-4">Yorumlar</h3>
                <div className="space-y-4 max-h-[240px] overflow-y-auto mb-4">
                  <div className="flex">
                    <img 
                      src="https://randomuser.me/api/portraits/women/44.jpg" 
                      alt="Commenter" 
                      className="w-8 h-8 rounded-full mr-3"
                    />
                    <div className="bg-gray-100 p-3 rounded-lg">
                      <p className="font-medium text-sm">Jane Smith</p>
                      <p className="text-sm">Çok güzel bir fotoğraf! Kamera ayarlarını paylaşır mısın?</p>
                    </div>
                  </div>
                  <div className="flex">
                    <img 
                      src="https://randomuser.me/api/portraits/men/22.jpg" 
                      alt="Commenter" 
                      className="w-8 h-8 rounded-full mr-3"
                    />
                    <div className="bg-gray-100 p-3 rounded-lg">
                      <p className="font-medium text-sm">Homer</p>
                      <p className="text-sm">Bu fotoğrafı nerede çektin? Harika görünüyor!</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex">
                  <img 
                    src="https://randomuser.me/api/portraits/men/32.jpg" 
                    alt="Your avatar" 
                    className="w-8 h-8 rounded-full mr-3"
                  />
                  <div className="flex-1">
                    <textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Yorum ekle..."
                      className="w-full border border-gray-300 rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                      rows={2}
                    />
                    <button className="mt-2 bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md transition-colors">
                      Gönder
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default PhotoDetail;