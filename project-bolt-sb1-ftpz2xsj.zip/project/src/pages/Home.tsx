import React, { useState } from 'react';
import Header from '../components/Header';
import Hero from '../components/Hero';
import PhotoGrid from '../components/PhotoGrid';
import CategorySidebar from '../components/CategorySidebar';
import TopPhotos from '../components/TopPhotos';
import TopCaptions from '../components/TopCaptions';
import Footer from '../components/Footer';
import { photos, topPhotos, topCaptions } from '../data';

const Home: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <Hero />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-1/4 space-y-6">
            <CategorySidebar 
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />
            <TopPhotos photos={topPhotos} />
            <TopCaptions photos={topCaptions} />
          </div>
          
          <div className="lg:w-3/4">
            <h2 className="text-2xl font-bold mb-6">
              {selectedCategory 
                ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Fotoğrafları` 
                : 'Tüm Fotoğraflar'}
            </h2>
            <PhotoGrid photos={photos} category={selectedCategory} />
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default Home;