import React from 'react';
import { Photo } from '../types';
import { Heart } from 'lucide-react';

interface TopPhotosProps {
  photos: Photo[];
}

const TopPhotos: React.FC<TopPhotosProps> = ({ photos }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-xl font-bold mb-4">En iyi fotoğraflar</h2>
      <div className="space-y-4">
        {photos.map((photo) => (
          <div key={photo.id} className="flex items-center">
            <img
              src={photo.imageUrl}
              alt={photo.title}
              className="w-16 h-16 object-cover rounded-md mr-3"
            />
            <div className="flex-1">
              <div className="flex items-center">
                <img 
                  src={photo.user.avatar} 
                  alt={photo.user.name} 
                  className="w-6 h-6 rounded-full mr-2"
                />
                <span className="text-sm text-gray-600">{photo.user.name}</span>
              </div>
              <p className="text-sm font-medium line-clamp-1">{photo.title}</p>
              <div className="flex items-center text-gray-500 text-xs mt-1">
                <Heart size={12} className="fill-current text-red-500 mr-1" />
                <span>{photo.likes} Likes</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopPhotos;