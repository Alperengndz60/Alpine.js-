import React from 'react';
import { Photo } from '../types';
import { MessageCircle } from 'lucide-react';

interface TopCaptionsProps {
  photos: Photo[];
}

const TopCaptions: React.FC<TopCaptionsProps> = ({ photos }) => {
  return (
    <div className="bg-white rounded-lg shadow p-4 mt-6">
      <h2 className="text-xl font-bold mb-4">Top Captions</h2>
      <div className="space-y-4">
        {photos.map((photo) => (
          <div key={photo.id} className="flex items-center">
            <img
              src={photo.user.avatar}
              alt={photo.user.name}
              className="w-10 h-10 rounded-full mr-3"
            />
            <div className="flex-1">
              <div className="flex items-center">
                <span className="text-sm font-medium">{photo.user.name}</span>
                <span className="text-xs text-gray-500 ml-2">5 Likes</span>
              </div>
              <p className="text-sm italic">"{photo.caption}"</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopCaptions;