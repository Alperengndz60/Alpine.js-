import React, { useState } from 'react';
import { WineIcon as AlpineIcon, User, Menu, LogOut } from 'lucide-react';
import LoginModal from './LoginModal';
import ProjectModal from './ProjectModal';

const Header: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showProjectModal, setShowProjectModal] = useState(false);

  const handleLogin = (email: string, password: string) => {
    if (email === 'alpine@gmail.com' && password === '6055') {
      setIsLoggedIn(true);
      setShowLoginModal(false);
    } else {
      alert('Geçersiz email veya şifre!');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  const handleHomeClick = () => {
    window.location.reload();
  };

  return (
    <header className="bg-gray-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <AlpineIcon size={24} />
          <span className="text-xl font-semibold">Alpine</span>
        </div>
        
        <div className="flex items-center space-x-6">
          <button 
            onClick={handleHomeClick}
            className="hover:text-blue-300 transition-colors"
          >
            Ana Sayfa
          </button>
          
          {isLoggedIn && (
            <button 
              onClick={() => setShowProjectModal(true)}
              className="hover:text-blue-300 transition-colors"
            >
              Gönderi Oluştur
            </button>
          )}
          
          {isLoggedIn ? (
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <img 
                  src="https://images.pexels.com/photos/892522/pexels-photo-892522.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                  alt="Profile" 
                  className="w-8 h-8 rounded-full border-2 border-blue-400 object-cover"
                />
                <span>Profil</span>
              </div>
              <button 
                onClick={handleLogout}
                className="flex items-center space-x-2 hover:text-red-400 transition-colors"
              >
                <LogOut size={20} />
                <span>Çıkış</span>
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setShowLoginModal(true)}
              className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-md transition-colors"
            >
              Giriş Yap
            </button>
          )}
        </div>
      </div>

      {showLoginModal && (
        <LoginModal
          onClose={() => setShowLoginModal(false)}
          onLogin={handleLogin}
        />
      )}

      {showProjectModal && (
        <ProjectModal
          onClose={() => setShowProjectModal(false)}
        />
      )}
    </header>
  );
};

export default Header;