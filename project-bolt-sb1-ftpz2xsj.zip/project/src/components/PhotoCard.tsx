import React, { useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark } from 'lucide-react';
import { Photo } from '../types';

interface PhotoCardProps {
  photo: Photo;
  featured?: boolean;
}

const PhotoCard: React.FC<PhotoCardProps> = ({ photo, featured = false }) => {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(photo.likes);
  const [saved, setSaved] = useState(false);

  const handleLike = () => {
    if (liked) {
      setLikes(likes - 1);
    } else {
      setLikes(likes + 1);
    }
    setLiked(!liked);
  };

  return (
    <div className={`bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 hover:shadow-lg ${featured ? 'border-2 border-blue-400' : ''}`}>
      <div className="relative">
        <img 
          src={photo.imageUrl} 
          alt={photo.title} 
          className="w-full h-64 object-cover"
        />
        <div className="absolute top-2 right-2 bg-white bg-opacity-80 rounded-md px-2 py-1 text-xs font-medium">
          {photo.category}
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-center mb-3">
          <img 
            src={photo.user.avatar} 
            alt={photo.user.name} 
            className="w-8 h-8 rounded-full mr-2"
          />
          <span className="text-sm text-gray-700">{photo.user.name}</span>
          {featured && (
            <span className="ml-auto text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
              Öne Çıkan
            </span>
          )}
        </div>
        
        <h3 className="text-xl font-semibold mb-2">{photo.title}</h3>
        <p className="text-gray-600 mb-4 italic">"{photo.caption}"</p>
        
        <div className="flex items-center justify-between text-gray-500">
          <div className="flex space-x-4">
            <button 
              className={`flex items-center ${liked ? 'text-red-500' : ''}`}
              onClick={handleLike}
            >
              <Heart size={18} className={liked ? 'fill-current' : ''} />
              <span className="ml-1 text-sm">{likes}</span>
            </button>
            <button className="flex items-center">
              <MessageCircle size={18} />
              <span className="ml-1 text-sm">{photo.comments}</span>
            </button>
            <button className="flex items-center">
              <Share2 size={18} />
            </button>
          </div>
          <button 
            className={`${saved ? 'text-blue-500' : ''}`}
            onClick={() => setSaved(!saved)}
          >
            <Bookmark size={18} className={saved ? 'fill-current' : ''} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default PhotoCard;