import React from 'react';
import { Mountain, User, PawPrint as Paw, Map, Moon } from 'lucide-react';
import { Category } from '../types';
import { categories } from '../data';

interface CategorySidebarProps {
  selectedCategory: string | null;
  onSelectCategory: (id: string | null) => void;
}

const CategorySidebar: React.FC<CategorySidebarProps> = ({ 
  selectedCategory, 
  onSelectCategory 
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'mountain':
        return <Mountain size={20} />;
      case 'user':
        return <User size={20} />;
      case 'paw':
        return <Paw size={20} />;
      case 'map':
        return <Map size={20} />;
      case 'moon':
        return <Moon size={20} />;
      default:
        return <Mountain size={20} />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h2 className="text-xl font-bold mb-4">Kategoriler</h2>
      <ul className="space-y-2">
        {categories.map((category) => (
          <li key={category.id}>
            <button
              onClick={() => onSelectCategory(category.id === selectedCategory ? null : category.id)}
              className={`w-full flex items-center p-2 rounded-md transition-colors ${
                selectedCategory === category.id 
                ? 'bg-blue-100 text-blue-700' 
                : 'hover:bg-gray-100'
              }`}
            >
              <span className="mr-3">{getIcon(category.icon)}</span>
              <span>{category.name}</span>
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CategorySidebar;