import React from 'react';
import { Photo } from '../types';
import PhotoCard from './PhotoCard';

interface PhotoGridProps {
  photos: Photo[];
  category: string | null;
}

const PhotoGrid: React.FC<PhotoGridProps> = ({ photos, category }) => {
  const filteredPhotos = category 
    ? photos.filter(photo => photo.category === category)
    : photos;

  return (
    <div className="container mx-auto py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPhotos.map((photo) => (
          <PhotoCard key={photo.id} photo={photo} />
        ))}
      </div>
    </div>
  );
};

export default PhotoGrid;