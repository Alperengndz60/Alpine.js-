import React from 'react';
import Home from './pages/Home';
// Uncomment to view photo detail page
// import PhotoDetail from './pages/PhotoDetail';

function App() {
  return (
    <div className="App">
      <Home />
      {/* <PhotoDetail /> */}
    </div>
  );
}

export default App;