import { Photo, Category, User } from '../types';

export const users: User[] = [
  {
    id: '1',
    name: 'John Doe',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg',
  },
  {
    id: '2',
    name: 'Jane Smith',
    avatar: 'https://randomuser.me/api/portraits/women/44.jpg',
  },
  {
    id: '3',
    name: 'Homer',
    avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
  },
];

export const categories: Category[] = [
  {
    id: 'landscapes',
    name: 'Manzaralar',
    icon: 'mountain',
  },
  {
    id: 'people',
    name: 'İnsanlar',
    icon: 'user',
  },
  {
    id: 'animals',
    name: 'Hayvanlar',
    icon: 'paw',
  },
  {
    id: 'travel',
    name: 'Seyat',
    icon: 'map',
  },
  {
    id: 'night',
    name: 'Geyah & Beyaz',
    icon: 'moon',
  },
];

export const photos: Photo[] = [
  {
    id: '1',
    title: 'Küçük Kedi',
    caption: 'Jedi kedisi sokağı koruyor',
    imageUrl: 'https://images.pexels.com/photos/2061057/pexels-photo-2061057.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'animals',
    likes: 42,
    comments: 5,
    user: users[0],
  },
  {
    id: '2',
    title: 'Dağ Manzarası',
    caption: 'Gökyüzüne uzanan zirveler',
    imageUrl: 'https://images.pexels.com/photos/1366909/pexels-photo-1366909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'landscapes',
    likes: 87,
    comments: 12,
    user: users[1],
  },
  {
    id: '3',
    title: 'Şehir Işıkları',
    caption: 'Gecenin karanlığında parlayan umut',
    imageUrl: 'https://images.pexels.com/photos/258447/pexels-photo-258447.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'night',
    likes: 65,
    comments: 8,
    user: users[2],
  },
  {
    id: '4',
    title: 'Güzel Sahil',
    caption: 'Dinlendirici bir tatil günü',
    imageUrl: 'https://images.pexels.com/photos/1450353/pexels-photo-1450353.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'travel',
    likes: 112,
    comments: 24,
    user: users[0],
  },
  {
    id: '5',
    title: 'Dans Eden İnsanlar',
    caption: 'Müziğin ritmiyle hayat bulan anlar',
    imageUrl: 'https://images.pexels.com/photos/2188012/pexels-photo-2188012.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'people',
    likes: 56,
    comments: 7,
    user: users[1],
  },
  {
    id: '6',
    title: 'Karlı Dağlar',
    caption: 'Beyaz örtüyle kaplı muhteşem manzara',
    imageUrl: 'https://images.pexels.com/photos/355747/pexels-photo-355747.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    category: 'landscapes',
    likes: 93,
    comments: 15,
    user: users[2],
  },
];

export const topPhotos = [
  photos[1],
  photos[3],
];

export const topCaptions = [
  photos[0],
  photos[2],
];